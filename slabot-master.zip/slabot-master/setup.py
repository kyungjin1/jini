#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
#    Copyright © Manoel Vilela 2016
#
#       @team: NewayPix
#    @project: slabot: Slack-Bot
#     @author: Manoel Vilela
#      @email: manoel_vilela@engineer.com
#

from setuptools import setup, find_packages
from codecs import open  # To use a consistent encoding
from os import path
from warnings import warn
import slabot

here = path.abspath(path.dirname(__file__))
readme = path.join(here, 'README.md')

try:
    import pypandoc
    long_description = pypandoc.convert(readme, 'rst', format='markdown')
except ImportError:
    warn("Only-for-developers: you need pypandoc for upload "
         "correct reStructuredText into PyPI home page")
    # Get the long description from the relevant file
    with open(readme, encoding='utf-8') as f:
        long_description = f.read()


with open('requirements.txt') as f:
    install_requires = list(map(lambda x: str(x).strip(), f.readlines()))


setup(
    name=slabot.__name__,
    version=slabot.__version__,
    description="A Slack RTM & Standalone API for creating bots with Python",
    long_description=long_description,
    classifiers=[
        "Environment :: Console",
        "Development Status :: 3 - Alpha",
        "Topic :: Utilities",
        "Operating System :: Unix",
        "Programming Language :: Python :: 3.4",
        "Programming Language :: Python :: 3.5",
    ],
    # Get strings from http://pypi.python.org/pypi?%3Aaction=list_classifiers
    keywords='slabot slack bot api AI',
    author=slabot.__author__,
    author_email=slabot.__email__,
    url=slabot.__url__,
    download_url="{u}/archive/v{v}.tar.gz".format(u=slabot.__url__,
                                                  v=slabot.__version__),
    zip_safe=False,
    license='MIT',
    packages=find_packages(exclude=['ez_setup', 'examples',
                                    'tests', 'docs', '__pycache__']),
    platforms='unix',
    install_requires=install_requires,
    package_data={
        'slabot': ['log/logging.json'],
    },
    extras_require={
        "Requires-Dist": ["pypandoc"]
    },

    entry_points={  # no entry-points yet
        # 'console_scripts': [
        #     'slabot = slabot.cli:main'
        # ]
    },
)
