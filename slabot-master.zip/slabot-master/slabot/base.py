#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
#    Copyright © Manoel Vilela 2016
#
#       @team: NewayPix
#    @project: slabot: Slack-Bot
#     @author: Manoel Vilela
#      @email: manoel_vilela@engineer.com
#

from abc import ABCMeta, abstractmethod
import random
from slabot.utils import normalizer


# interface for commands
class Action(metaclass=ABCMeta):

    def __init__(self, action, data, **kwargs):
        self.action = action
        self.data = data

        for k, v in kwargs.items():
            setattr(self, k, v)

    def __repr__(self):
        return "<{!r} :: {!r} -> {!r}".format(self.__class__.__name__,
                                              self.action,
                                              self.data)

    @abstractmethod
    def eval(self, reply):
        """Eval the action if can react"""
        pass

    @abstractmethod
    def reaction(self, reply):
        """Reaction for the action"""
        pass


class Trigger(Action):

    def reaction(self, reply):
        self.action(reply)


class Command(Action):
    pass


class ChatterBot(metaclass=ABCMeta):

    @abstractmethod
    def event_handler(self, reply):
        """To generate and treat the events of RTM"""
        pass

    @abstractmethod
    def command_handler(self, reply):
        """Command handling of chatter bots"""
        pass


class StartMessage(metaclass=ABCMeta):

    @abstractmethod
    def setup(self):
        """Section to run the start_message"""
        pass

    @abstractmethod
    def start_message(self):
        """The start message when bot is online"""
        pass


class Reply(Command):

    def eval(self, reply):
        return reply.get('text') and self.action in normalizer(reply['text'])

    def data_handler(self, bot, reply):
        data = self.data
        for mode in self.mode.split('-'):
            if mode == 'random':
                data = random.choice(self.data)
            elif mode == 'answer':
                data = data.format(user=bot.get_realname(reply['user']))
            elif mode == 'order':
                data = data.format(neighbor=self.parse_reply(bot, reply))
            elif mode == 'simple':
                break
            else:
                data = 'Not Implemented Yet! Call your Mom, sucker!'

        return data

    def parse_reply(self, bot, reply):
        command = self.command
        parts = reply['text'].lower().split(command)
        if parts:
            neigbhor = parts[-1]
            if neigbhor:
                return neigbhor.split()[0]

        if 'blame' in reply.get('text'):
            message = "Oh, *sucker*! `{command}`... but who?".format_map(
                locals())
            bot.send_message(message, reply['channel'])
            return bot.get_realname(reply['user']),

        return None
