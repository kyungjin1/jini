#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
#    Copyright © Manoel Vilela 2016
#
#       @team: NewayPix
#    @project: slabot: Slack-Bot
#     @author: Manoel Vilela
#      @email: manoel_vilela@engineer.com
#

import json
import logging.config
import os


def setup_logging(path='logging.json'):
    """Setup logging configuration"""
    cdir = os.path.dirname(__file__)
    with open(cdir + '/' + path, 'rt') as f:
        config = json.load(f)
    logging.config.dictConfig(config)

setup_logging()
logger = logging.getLogger(__name__)
