#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
#    Copyright © Manoel Vilela 2016
#
#       @team: NewayPix
#    @project: slabot: Slack-Bot
#     @author: Manoel Vilela
#      @email: manoel_vilela@engineer.com
#

from slabot import base
from random import choice
from os.path import basename
from glob import iglob
import asyncio


class Message(base.Reply):

    @asyncio.coroutine
    def reaction(self, bot, reply):
        message = self.data_handler(bot, reply)
        prepared = self.nfixer(message, **self.__dict__)
        yield from bot.send_message(prepared, reply['channel'])

    def nfixer(self, message, prefix='', suffix='', separator=' ', **kwargs):
        return separator.join([prefix or '', message, suffix or ''])


class File(base.Reply):

    @asyncio.coroutine
    def reaction(self, bot, reply):
        path = self.data_handler(bot, reply)
        files = [x for x in iglob(path)]
        image_path = choice(files)

        try:
            yield from bot.send_file(image_path, reply['channel'],
                                     filename=basename(image_path),
                                     initial_comment=self.comment)
        except Exception:
            yield from asyncio.sleep(0.1)

classes = {
    "file": File,
    "message": Message,
}


def builder(commands_data):
    try:
        commands = []
        for command, reaction_name in commands_data['commands'].items():
            reaction = commands_data['reactions'][reaction_name]
            data = commands_data['data'][reaction_name]
            cls = classes[reaction['type']]
            commands.append(cls(command, data, **reaction))
    except KeyError:
        raise SyntaxError("Bad configuration at yaml config file")

    return commands
