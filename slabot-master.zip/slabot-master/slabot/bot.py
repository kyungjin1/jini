#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
#    Copyright © Manoel Vilela 2016
#
#       @team: NewayPix
#    @project: slabot: Slack-Bot
#     @author: Manoel Vilela
#      @email: manoel_vilela@engineer.com
#

import asyncio
import time
import sys
from functools import partial
from pprint import pformat
from logging import DEBUG
from concurrent.futures import ThreadPoolExecutor

from slacker import Slacker
from slackclient import SlackClient
from slabot.log import logger
from slabot import base
import slabot.triggers


if sys.version_info <= (3, 4):
    asyncio.ensure_future = asyncio.async


# Slacker is newer  ↓
class SlackBot(base.ChatterBot, Slacker):

    _usernames = None
    logger = logger
    event_loop = asyncio.get_event_loop()  # global event loop
    pool = ThreadPoolExecutor(8)  # global bot pool

    def __init__(self, token, refresh=5, timeout=30, debug=False,
                 channel="random", username='slackbot', commands=[],
                 triggers=[], **kwargs):
        super().__init__(token)
        self.slack_client = SlackClient(token)  # RTM Connection
        self.channel = channel
        self.last_ping = 0
        self.last_pong = 0
        self.refresh = refresh
        self.timeout = timeout
        self.debug = debug
        self.commands = commands
        self.username = username
        self.user_id = self.get_user_id(username)
        self.triggers = triggers + [slabot.triggers.Reply(self.command_handler,
                                                          self.username)]
        if self.debug:
            self.logger.setLevel(DEBUG)

        for k, v in kwargs.items():
            setattr(self, k, v)

    def __call__(self, call):
        return self.slack_client.api_call(call)

    def setup(self):
        """Method to initialize database or other things"""

    def connect(self):
        status = self.slack_client.rtm_connect()
        self.setup()  # heavy side effect, need better design
        return status

    @asyncio.coroutine
    def start(self):
        self.running = self.connect()

        while self.running:
            try:
                for reply in self.slack_client.rtm_read():
                    self.event_handler(reply)

                self.auto_ping()
                self.timeout_handler()
                yield from asyncio.sleep(0.1)
            except Exception as e:
                self.logger.error("Some crazy error occurs!")
                self.logger.exception(e)

        return self.restart()

    def auto_ping(self):
        now = time.time()
        if now > self.last_ping + self.refresh:
            self.slack_client.server.ping()
            self.last_ping = now

    def restart(self):
        self.logger.info("Disconnected. "
                         "Reconnecting in {}s".format(self.refresh))
        time.sleep(self.refresh)
        return self.start()

    def event_handler(self, reply):
        if reply.get('type') == 'pong':
            self.last_pong = time.time()

        for trigger in self.triggers:
            if trigger.eval(reply):
                trigger.reaction(reply)

        if self.debug:
            self.logger.info("Event received: {}".format(pformat(reply)))

    def timeout_handler(self):
        if (self.last_pong - self.timeout) > time.time():
            self.running = False

    def command_handler(self, reply):
        for command in self.commands:
            if command.eval(reply):
                self.run_coroutine(command.reaction(self, reply))

    def send_message(self, message, channel=None, **kwargs):
        if not channel:
            channel = self.channel
        self.chat.post_message(channel,
                               message,
                               as_user=True,
                               **kwargs)

    def send_file(self, filepath, channel=None, **kwargs):
        if not channel:
            channel = self.channel
        self.files.upload(
            filepath,
            channels=[channel],
            **kwargs
        )

    def get_realname(self, user_id):
        return self.users.info(user_id).body['user']['profile']['real_name']

    @property
    def usernames_map(self):
        if not self._usernames:
            users = self.users.list().body
            self._usernames = {
                user['id']: user['name']
                for user in users['members']
                if not user['deleted']
            }

        return self._usernames

    def get_user_id(self, name):
        match = [k for k, v in self.usernames_map.items() if name == v]
        return (match or [None]).pop(0)

    def pool_execute(self, func, *args, **kwargs):
        return self.event_loop.run_in_executor(
            self.pool, partial(func, *args, **kwargs))

    def run_coroutine(self, coroutine):
        asyncio.async(coroutine)

    @staticmethod
    def tasks():
        return asyncio.gather(*asyncio.Task.all_tasks())
