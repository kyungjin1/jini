#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
#    Copyright © Manoel Vilela 2016
#
#       @team: NewayPix
#    @project: slabot: Slack-Bot
#     @author: Manoel Vilela
#      @email: manoel_vilela@engineer.com
#


from slabot import base


class Reply(base.Trigger):

    def eval(self, reply):
        return reply.get('user') != self.data and reply.get('type') != 'pong'

classes = {
    "reaction": Reply
}
