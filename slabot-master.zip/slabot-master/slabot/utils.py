#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
#    Copyright © Manoel Vilela 2016
#
#       @team: NewayPix
#    @project: slabot: Slack-Bot
#     @author: Manoel Vilela
#      @email: manoel_vilela@engineer.com
#


def normalizer(text):
    from string import punctuation
    for c in punctuation:
        text = text.replace(c, '')

    return " ".join(text.split()).lower()
