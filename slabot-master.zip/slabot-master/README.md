
[![Build Status](https://travis-ci.org/ryukinix/slabot.svg?branch=master)](https://travis-ci.org/ryukinix/slabot)
[![codecov](https://codecov.io/gh/ryukinix/slabot/branch/master/graph/badge.svg)](https://codecov.io/gh/ryukinix/slabot)
[![Requirements Status](https://requires.io/github/ryukinix/slabot/requirements.svg?branch=master)](https://requires.io/github/ryukinix/slabot/requirements/?branch=master)
[![PyPi version](https://img.shields.io/pypi/v/slabot.svg)](https://pypi.python.org/pypi/slabot/)
[![PyPI pyversions](https://img.shields.io/pypi/pyversions/slabot.svg)](https://pypi.python.org/pypi/slabot/)
[![PyPI status](https://img.shields.io/pypi/status/slabot.svg)](https://pypi.python.org/pypi/slabot/)
[![HitCount](https://hitt.herokuapp.com/ryukinix/slabot.svg)](https://github.com/ryukinix/slabot)

# slack-bot
A Slack-Bot API for normal & RTM bots, extensuful, modular,  and oriented a triggers (waiting action) and commands (reaction).

# Getting Started

`sudo pip3 install slabot`

# Example

A [full featured RTM bot](examples/lain-bot) with the default triggers:
```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
#    Copyright © Manoel Vilela 2016
#
#       @team: NewayPix
#    @project: slabot: Slack-Bot
#     @author: Manoel Vilela
#      @email: manoel_vilela@engineer.com
#

# stdlib
import yaml

# slack-bot
from slabot.log import logger
from slabot.bot import SlackBot
from slabot import commands


def lain_life():
    cmds_data = yaml.load(open('commands.yml'))  # parse the commands yml
    slacks = yaml.load(open('tokens.yml'))  # get the tokens and user_ids
    cmds = commands.builder(cmds_data)  # build the commands
    for slack in slacks.values():  # get the team setup
        lain_bot = SlackBot(slack['token'], commands=cmds,
                            config=cmds_data, channel='random',
                            user_id=slack['user_id'], startup=False,
                            debug=True)
        SlackBot.event_loop.create_task(lain_bot.start())
    SlackBot.event_loop.run_forever()


if __name__ == '__main__':
    try:
        lain_life()
    except Exception as e:
        logger.error("Some crazy error occurs!")
        logger.exception(e)
    finally:
        SlackBot.event_loop.close()
        print("Bot down.")

```


# Specification:

* Just Python3 (because usage of asyncio)

# Authors & Contributors

* Manoel Vilela

# License
MIT